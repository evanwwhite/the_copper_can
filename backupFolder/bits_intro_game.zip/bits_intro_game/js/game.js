/*
  Bits Box prototype
  ------------------------------------------------------------
  What this does:
  1. Shows an intro/tutorial title screen.
  2. The Play button starts the real game screen.
  3. The game begins as a mostly blank page with a copper bits counter.
  4. Copper bits accumulate once per second.
  5. At 10 copper bits, a new button appears.
  6. Clicking that button unlocks a simple manual action.

  This keeps the early-game pacing similar to an unfolding incremental game:
  start with almost nothing, wait, then reveal one new interaction.
*/

const BIT_UNLOCK_AMOUNT = 10;
const SAVE_KEY = "bitsBoxPrototypeSave";

const game = {
  screen: "intro",
  copperBits: 0,
  copperBitsPerSecond: 1,
  hasSeenFirstUnlock: false,
  hasUnlockedManualSearch: false,
  timerId: null,
};

const statusBar = document.getElementById("statusBar");
const mainContent = document.getElementById("mainContent");

function saveGame() {
  const saveData = {
    screen: game.screen,
    copperBits: game.copperBits,
    copperBitsPerSecond: game.copperBitsPerSecond,
    hasSeenFirstUnlock: game.hasSeenFirstUnlock,
    hasUnlockedManualSearch: game.hasUnlockedManualSearch,
  };

  localStorage.setItem(SAVE_KEY, JSON.stringify(saveData));
}

function loadGame() {
  const rawSave = localStorage.getItem(SAVE_KEY);

  if (!rawSave) return;

  try {
    const saveData = JSON.parse(rawSave);

    game.screen = saveData.screen ?? "intro";
    game.copperBits = saveData.copperBits ?? 0;
    game.copperBitsPerSecond = saveData.copperBitsPerSecond ?? 1;
    game.hasSeenFirstUnlock = saveData.hasSeenFirstUnlock ?? false;
    game.hasUnlockedManualSearch = saveData.hasUnlockedManualSearch ?? false;
  } catch {
    localStorage.removeItem(SAVE_KEY);
  }
}

function startTimer() {
  if (game.timerId !== null) return;

  game.timerId = window.setInterval(() => {
    if (game.screen !== "game") return;

    game.copperBits += game.copperBitsPerSecond;

    if (game.copperBits >= BIT_UNLOCK_AMOUNT) {
      game.hasSeenFirstUnlock = true;
    }

    saveGame();
    renderGameScreen();
  }, 1000);
}

function renderIntroScreen() {
  game.screen = "intro";
  saveGame();

  statusBar.textContent = "";

  mainContent.innerHTML = String.raw`


                         ____  _ _         ____            
                        | __ )(_) |_ ___  | __ )  _____  __
                        |  _ \| | __/ __| |  _ \ / _ \ \/ /
                        | |_) | | |_\__ \ | |_) | (_) >  < 
                        |____/|_|\__|___/ |____/ \___/_/\_\


                              an unfolding text game


             You find a small copper bit resting in an empty box.
             It does not look important yet.


                                <span id="playButton" class="asciiRealButton">Play</span>


`;

  document.getElementById("playButton").addEventListener("click", startNewGame);
}

function startNewGame() {
  game.screen = "game";
  game.copperBits = 0;
  game.copperBitsPerSecond = 1;
  game.hasSeenFirstUnlock = false;
  game.hasUnlockedManualSearch = false;

  saveGame();
  startTimer();
  renderGameScreen();
}

function continueGame() {
  game.screen = "game";
  saveGame();
  startTimer();
  renderGameScreen();
}

function renderGameScreen() {
  statusBar.textContent = `You have ${game.copperBits} copper bit${game.copperBits === 1 ? "" : "s"}.`;

  let content = `









`;

  if (game.hasSeenFirstUnlock && !game.hasUnlockedManualSearch) {
    content += `                         Something glints in the dust.

                         <span id="searchDustButton" class="asciiRealButton">Search the dust</span>
`;
  }

  if (game.hasUnlockedManualSearch) {
    content += `                         You can now search the dust for loose bits.

                         <span id="gatherBitButton" class="asciiRealButton">Pick up a copper bit</span>

                         Copper bits appear on their own,
                         but now you know where to look.
`;
  }

  content += `



                         <span id="resetButton" class="asciiButton">reset prototype</span>
`;

  mainContent.innerHTML = content;

  const searchDustButton = document.getElementById("searchDustButton");
  if (searchDustButton) {
    searchDustButton.addEventListener("click", unlockManualSearch);
  }

  const gatherBitButton = document.getElementById("gatherBitButton");
  if (gatherBitButton) {
    gatherBitButton.addEventListener("click", gatherCopperBit);
  }

  const resetButton = document.getElementById("resetButton");
  if (resetButton) {
    resetButton.addEventListener("click", resetPrototype);
  }
}

function unlockManualSearch() {
  game.hasUnlockedManualSearch = true;
  saveGame();
  renderGameScreen();
}

function gatherCopperBit() {
  game.copperBits += 1;
  saveGame();
  renderGameScreen();
}

function resetPrototype() {
  localStorage.removeItem(SAVE_KEY);
  game.screen = "intro";
  game.copperBits = 0;
  game.copperBitsPerSecond = 1;
  game.hasSeenFirstUnlock = false;
  game.hasUnlockedManualSearch = false;

  renderIntroScreen();
}

function boot() {
  loadGame();

  if (game.screen === "game") {
    continueGame();
  } else {
    renderIntroScreen();
  }
}

boot();
